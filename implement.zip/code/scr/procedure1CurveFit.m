% index dataframe with unique combinations of compound and experiment identifiers
[sptx,svals,sidx] = DFindex(dtScore,{'master_cpd_id','experiment_id'});

% reconcile relationships between experiment identifiers and cell lines
utExpt = unique([mtExpt.experiment_id mtExpt.master_ccl_id],'rows');
assert(isequal(utExpt(:,1),(1:max(utExpt(:,1)))'),'Experiment identifiers not unique or not in sequence.');

% define set of curves to be fit (demo: a single random compound)
tCRC = find(sidx(:,1)==randsample(unique(sidx(:,1)),1));
nCRC = numel(tCRC);

% create MATLAB struct for curve-fitting results
CRC = struct();

% define concentration limits for area-under-curve (AUC) integration
t_mG = min(log2(dtScore.cpd_conc_umol)); 
t_xG = max(log2(dtScore.cpd_conc_umol));

% initialize curve-fit parameters and options
betaX = [NaN -1/log(19) 1 0]; 
opts = statset('TolX',1e-3,'TolFun',1e-3,'MaxFunEvals',1024, 'MaxIter',1024,...
    'Display','off','FunValCheck','off','Robust','off','WgtFun','logistic');

for tt=1:nCRC % for each curve to be fit
    
    t = tCRC(tt);
    
    % get data points for current curve fit and integration    
    tNP0 = numel(sptx{t});
    tQC = unique(dtScore.qc_type(sptx{t}));
    assert(isscalar(tQC),'Too many values of QCtype.');
    [tx,ti] = sort(log2(dtScore.cpd_conc_umol(cell2mat(sptx(t)))));
    ty = dtScore.cpd_avg_pv(cell2mat(sptx(t)));
    ty = ty(ti);
    
    % seed curve fit parameters and make initial guess for EC50 from the data
    beta0 = betaX;
    if (min(ty)<0.5)
        beta0(1) = tx(find(ty<0.5,1,'first'));
    else
        beta0(1) = median(tx);
    end
    
    % remove final two data points for QCtype=2
    if (tQC==2)
        tNP = tNP0-2;
        tx = tx(1:end-2);
        ty = ty(1:end-2);

    % remove final data point for QCtype=1
    elseif (tQC==1)
        tNP = tNP0-1;
        tx = tx(1:end-1);
        ty = ty(1:end-1);
        
    % apply Cook's distance censoring for QCtype=3
    elseif (tQC>2)
        tKP = cooksdist(tx,ty,beta0);
        if (ty(end-1)<0.5)  % disallow discard of penultimate point if ty<0.5
            tKP(end-1) = true;
        end
        if (ty(end)<0.5)    % disallow discard of final point if ty<0.5
            tKP(end) = true;
        end
        tx = tx(tKP);
        ty = ty(tKP);
        tNP = numel(tx);
        
    % otherwise keep all data points
    else
        tNP = tNP0;
    end
    
    % skip curves with fewer than 5 data points remaining
    if (tNP<5)
        
        CRC(tt).t = t;
        CRC(tt).master_cpd_id = svals.master_cpd_id(sidx(t,1));
        CRC(tt).experiment_id = svals.experiment_id(sidx(t,2));
        CRC(tt).tQC = tQC;
        CRC(tt).tNP0 = tNP0;
        CRC(tt).tNP = tNP;
        CRC(tt).tx = tx;
        CRC(tt).ty = ty;
        CRC(tt).tfx = NaN;
        CRC(tt).tci = NaN;
        CRC(tt).beta0 = beta0;
        CRC(tt).beta = NaN;
        CRC(tt).betaCI = NaN;
        CRC(tt).betaN = 0;
        CRC(tt).t_mG = t_mG;
        CRC(tt).t_xG = t_xG;
        CRC(tt).r_G = NaN;       
        continue;

    % fit curves with at least 5 data points remaining
    else
        
        % provisionally fit 3-parameter sigmoid curve to data points 
        [beta,pRES,~,pCOV,pMSE] = nlinfit(tx,ty,@sig3upper,beta0([1 2 4]),opts);   
        [tfx,tci] = nlpredci(@sig3upper,tx,beta,pRES,'covar',pCOV,'mse',pMSE);
        betaCI = nlparci(beta,pRES,'covar',pCOV);
        r_G = integral(@(tx) sig3upper(beta,tx),t_mG,t_xG)./(t_xG-t_mG);
        
        % re-fit using 2-parameter sigmoid curve if initial EC50 is above the highest concentration
        if (beta(1)>tx(end))
            [beta,pRES,~,pCOV,pMSE] = nlinfit(tx,ty,@sig2both,beta0([1 2]),opts);   
            [tfx,tci] = nlpredci(@sig2both,tx,beta,pRES,'covar',pCOV,'mse',pMSE);
            betaCI = nlparci(beta,pRES,'covar',pCOV);
            r_G = integral(@(tx) sig2both(beta,tx),t_mG,t_xG)./(t_xG-t_mG);
        end
        betaN = numel(beta);

    end
    
    % add curve-fitting results to MATLAB struct
    CRC(tt).t = t;
    CRC(tt).master_cpd_id = svals.master_cpd_id(sidx(t,1));
    CRC(tt).experiment_id = svals.experiment_id(sidx(t,2));
    CRC(tt).tQC = tQC;
    CRC(tt).tNP0 = tNP0;
    CRC(tt).tNP = tNP;
    CRC(tt).tx = tx;
    CRC(tt).ty = ty;
    CRC(tt).tfx = tfx;
    CRC(tt).tci = tci;
    CRC(tt).beta0 = beta0;
    CRC(tt).beta = beta;
    CRC(tt).betaCI = betaCI;
    CRC(tt).betaN = betaN;
    CRC(tt).t_mG = t_mG;
    CRC(tt).t_xG = t_xG;
    CRC(tt).r_G = r_G;
    sprintf('Finished curve fit %i of %i.',tt,nCRC)
    
end

% setup dataframes to output tables of fitted-curve per-point and per-curve data
outPts = struct('curve_id',[],'master_cpd_id',[],'experiment_id',[], ...
                'cpd_conc_umol',[],'cpd_avg_pv',[],'cpd_pred_pv',[],'cpd_pv_errorbar',[]);
outFit = struct();

for z=1:nCRC % for each curve to be output 
        
    % tabulate curve, compound and experiment IDs, number of points used
    outFit.curve_id(z,1) = CRC(z).t;
    outFit.master_cpd_id(z,1) = CRC(z).master_cpd_id;
    outFit.experiment_id(z,1) = CRC(z).experiment_id;
    outFit.conc_pts_tot(z,1) = tNP0;
    tNP = CRC(z).tNP;
    outFit.conc_pts_fit(z,1) = tNP;
    
    % tabulate output data for curves successfully fit
    if (tNP>4)
        betaN = CRC(z).betaN;
        outFit.fit_num_param(z,1) = betaN;
        outFit.pred_pv_min_value(z,1) = min(CRC(z).tfx);
        outFit.pred_pv_high_conc(z,1) = CRC(z).tfx(end); 
        outFit.area_under_curve(z,1) = CRC(z).r_G;
        outFit.apparent_ec50_umol(z,1) = power(2,CRC(z).beta(1));
        outFit.p1_center(z,1) = CRC(z).beta(1);
        outFit.p1_conf_int_low(z,1) = CRC(z).betaCI(1,1);
        outFit.p1_conf_int_high(z,1) = CRC(z).betaCI(1,2);
        outFit.p2_slope(z,1) = CRC(z).beta(2);
        outFit.p2_conf_int_low(z,1) = CRC(z).betaCI(2,1);
        outFit.p2_conf_int_high(z,1) = CRC(z).betaCI(2,2);
        
        % append per-curve data from 2-parameter fit
        if (betaN<3)
            outFit.p3_total_decline(z,1) = 1;
            outFit.p3_conf_int_low(z,1) = NaN;
            outFit.p3_conf_int_high(z,1) = NaN;
            outFit.p4_baseline(z,1) = 0;
            outFit.p4_conf_int_low(z,1) = NaN;
            outFit.p4_conf_int_high(z,1) = NaN;

        % append per-curve data from 3-parameter fit
        else
            outFit.p3_total_decline(z,1) = 1-CRC(z).beta(3); % VD/PAC fixed 2014/09/05
            outFit.p3_conf_int_low(z,1) = NaN;
            outFit.p3_conf_int_high(z,1) = NaN;
            outFit.p4_baseline(z,1) = CRC(z).beta(3);
            outFit.p4_conf_int_low(z,1) = CRC(z).betaCI(3,1);
            outFit.p4_conf_int_high(z,1) = CRC(z).betaCI(3,2);
        end
        
        % append per-point data to growing dataframe
        outPts.curve_id = [outPts.curve_id; repmat(CRC(z).t,numel(CRC(z).tx),1)];
        outPts.master_cpd_id = [outPts.master_cpd_id; repmat(CRC(z).master_cpd_id,numel(CRC(z).tx),1)];
        outPts.experiment_id = [outPts.experiment_id; repmat(CRC(z).experiment_id,numel(CRC(z).tx),1)];
        outPts.cpd_conc_umol = [outPts.cpd_conc_umol; power(2,CRC(z).tx)];
        outPts.cpd_avg_pv = [outPts.cpd_avg_pv; CRC(z).ty];
        outPts.cpd_pred_pv = [outPts.cpd_pred_pv; CRC(z).tfx];
        outPts.cpd_pv_errorbar = [outPts.cpd_pv_errorbar; CRC(z).tci];
    
    % write null per-curve output if no curve is fit    
    else
        outFit.fit_num_param(z,1) = 0;
        outFit.pred_pv_min_value(z,1) = NaN;
        outFit.pred_pv_high_conc(z,1) = NaN;
        outFit.area_under_curve(z,1) = NaN;
        outFit.apparent_ec50_umol(z,1) = NaN;
        outFit.p1_center(z,1) = NaN;
        outFit.p1_conf_int_low(z,1) = NaN;
        outFit.p1_conf_int_high(z,1) = NaN;
        outFit.p2_slope(z,1) = NaN;
        outFit.p2_conf_int_low(z,1) = NaN;
        outFit.p2_conf_int_high(z,1) = NaN;
        outFit.p3_total_decline(z,1) = NaN;
        outFit.p3_conf_int_low(z,1) = NaN;
        outFit.p3_conf_int_high(z,1) = NaN;
        outFit.p4_baseline(z,1) = NaN;
        outFit.p4_conf_int_low(z,1) = NaN;
        outFit.p4_conf_int_high(z,1) = NaN;
    end
    sprintf('Finished data aggregation %i of %i.',z,nCRC)
    
end

% define post-curve-fit quality-control filters
    % no curve fit was attempted
    f0 = outFit.fit_num_param==0;
    % fewer than 8 total points were used
    f1 = outFit.conc_pts_fit<8;
    % Cook's distance censored more than 1/3 of the points
    f2 = outFit.conc_pts_fit<(2/3)*outFit.conc_pts_tot;
    % no part of the fit curve is below PV = 1.25
    f3 = outFit.pred_pv_min_value>1.25;
    % an increasing curve (within roundoff tolerance) starts below PV = 0.8
    f4 = (outFit.pred_pv_min_value<0.8)&((outFit.pred_pv_high_conc-outFit.pred_pv_min_value)>(2*10^-5));
    % a predicted value falls below PV = -0.1
    f5 = outFit.pred_pv_min_value<-0.1;
    % area-under-curve falls below -0.05
    f6 = outFit.area_under_curve<-0.05;
    % area-under-curve exceeds 1.25, except sufficiently increasing curves
    f7 = (outFit.area_under_curve>1.25)&((outFit.pred_pv_high_conc-outFit.pred_pv_min_value)>0.25);
    fk = ~(f0|f1|f2|f3|f4|f5|f6|f7);

% apply post-curve-fit quality-control filters
outFit = DFkeeprow(outFit,fk);
outPts = DFkeeprow(outPts,ismember(outPts.curve_id,outFit.curve_id));

% resolve experiment identifiers to cell line identifiers
outFit.master_ccl_id = utExpt(outFit.experiment_id,2);
outPts.master_ccl_id = utExpt(outPts.experiment_id,2);

% write output files for downstream analysis
DFwrite(outFit,'output.P1.per-curve.txt',[wf '\out']);
DFwrite(outPts,'output.P1.per-point.txt',[wf '\out']);

% clean up workspace
clear ans b* f* *CRC opts p* r_G s* t* u* z;
