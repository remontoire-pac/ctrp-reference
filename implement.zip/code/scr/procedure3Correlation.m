% index dataframe with unique combinations of compound and cell line identifiers
[sptxS,svalsS,sidxS] = DFindex(dtAUC21,{'master_cpd_id','master_ccl_id'});

% create matrix of sensitivity values for compounds X cell lines
dmAUC21 = nan(numel(svalsS.master_cpd_id),numel(svalsS.master_ccl_id));
for z=1:numel(sptxS)
    dmAUC21(sidxS(z,1),sidxS(z,2)) = mean(dtAUC21.area_under_curve(cell2mat(sptxS(z))));
end

% index dataframe with unique combinations of gene and cell line identifiers
[sptxG,svalsG,sidxG] = DFindex(dtGEX,{'idx_gene_feature','master_ccl_id'});

% create matrix of expression values for genes X cell lines
dmGEX = nan(numel(svalsG.idx_gene_feature),numel(svalsG.master_ccl_id));
for z=1:numel(sptxG)
    dmGEX(sidxG(z,1),sidxG(z,2)) = mean(dtGEX.mrna_expression_avg_log2(cell2mat(sptxG(z))));
end

% define subset of cell lines to be tested (demo: a single lineage with at least 16 examples)
[uPS,~,uID] = unique(mtCCL.ccle_primary_site);
kps = randsample(uPS(~strcmp(uPS,{''})&histc(uID,1:numel(uPS))>=16),1);
kid = mtCCL.master_ccl_id(strcmp(mtCCL.ccle_primary_site,kps));

% restrict cell lines to those with both sensitivity and expression data
kid = kid(ismember(kid,svalsS.master_ccl_id)&ismember(kid,svalsG.master_ccl_id));
dmAUC21 = dmAUC21(:,ismember(svalsS.master_ccl_id,kid));
dmGEX = dmGEX(:,ismember(svalsG.master_ccl_id,kid));

% restrict genes to those with adequate dynamic range
kg = (range(dmGEX,2)==max(range(dmGEX,2))) | ...
     ((std(dmGEX,[],2)>2*norminv(0.75))&(range(dmGEX,2)>3));
dmGEX = dmGEX(kg,:);
kgi = svalsG.idx_gene_feature(kg);

% restrict compounds to those with adequate effects and differential effects
tCpd = find((range(dmAUC21,2)==max(range(dmAUC21,2))) | ...
           ((range(dmAUC21,2)>3)&min(dmAUC21,[],2)<13));

% define set of compounds to be fit (demo: up to a dozen random compounds)
tCpd = sort(randsample(tCpd,min(12,numel(tCpd))));

% calculate raw correlation output
[pwCZ,pwCC,pwCT] = nanpw2fishz(dmAUC21(tCpd,:),dmGEX);

% compute p-values and index to filter output statistically
pwCP = nan(size(pwCZ));
pwCP(:) = normcdf(-abs(pwCZ(:)));
pind = find(pwCP==min(pwCP(:))|pwCP<0.025/numel(~isnan(pwCP)));

% create results dataframe using filtered output
[outCor.cor_row_id,outCor.cor_col_id] = ind2sub(size(pwCP),pind);

% record context, compound ID, and gene ID 
outCor.context = repmat(kps,numel(outCor.cor_row_id),1);
outCor.index_cpd = tCpd(outCor.cor_row_id);
outCor.master_cpd_id = svalsS.master_cpd_id(tCpd(outCor.cor_row_id));
outCor.idx_gene_feature = svalsG.idx_gene_feature(kgi(outCor.cor_col_id));

% use index to record correlation p-value, z-score, coefficient, and number of cell lines
outCor.cor_p_val = pwCP(pind);
outCor.cor_z_score = pwCZ(pind);
outCor.cor_coef = pwCC(pind);
outCor.num_of_ccl = pwCT(pind);

% define correlation quality-control filters
f0 = (outCor.cor_p_val==min(outCor.cor_p_val));
f1 = dmAUC21(tCpd(outCor.cor_row_id),:);
f1(tiedrank(f1')'==repmat(min(tiedrank(f1')',[],2),1,size(f1,2))) = NaN;
f1 = (range(f1,2)>3);
f2 = dmAUC21(tCpd(outCor.cor_row_id),:);
f2(tiedrank(-f2')'==repmat(min(tiedrank(-f2')',[],2),1,size(f2,2))) = NaN;
f2 = (range(f2,2)>3);
f3 = dmGEX(outCor.cor_col_id,:);
f3(tiedrank(f3')'==repmat(min(tiedrank(f3')',[],2),1,size(f3,2))) = NaN;
f3 = (range(f3,2)>3);
f4 = dmGEX(outCor.cor_col_id,:);
f4(tiedrank(-f4')'==repmat(min(tiedrank(-f4')',[],2),1,size(f4,2))) = NaN;
f4 = (range(f4,2)>3);
f5 = (outCor.num_of_ccl>=8);
fk = (f0|(f1&f2&f3&f4&f5));

% apply correlation quality-control filters
outCor = DFkeeprow(outCor,fk);

% write output files for downstream analysis
DFwrite(outCor,'output.P3.correlation.txt',[wf filesep 'out']);

% clean up workspace
clear ans f* k* p* s* *Cpd u* z*;
