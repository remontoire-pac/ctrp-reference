% index dataframe with unique combinations of compound and cell line identifiers
[sptx,svals,sidx] = DFindex(dtAUC22,{'index_cpd','index_ccl'});

% verify that indices for rows and columns match compounds and cell lines, respectively
assert(isequal(svals.index_cpd,(1:max(svals.index_cpd))'),'Compound identifiers not unique or not sorted.');
assert(isequal(svals.index_ccl,(1:max(svals.index_ccl))'),'Cell line identifiers not unique or not sorted.');

% create matrix of sensitivity values for compounds by cell lines
dmAUC22 = nan(numel(svals.index_cpd),numel(svals.index_ccl));
for z=1:numel(sptx)
    dmAUC22(sidx(z,1),sidx(z,2)) = dtAUC22.area_under_curve(cell2mat(sptx(z)));
end

% create indicator matrix of cell lineage features by cell lines
diCCL = false(numel(daCCL.cell_line_feature),size(dmAUC22,2));
for z=1:numel(daCCL.cell_line_feature)
    diCCL(z,cell2mat(textscan(cell2mat(strrep(daCCL.index_ccl(z),';',' ')),'%u'))) = true;
end

% define set of cell lines to be tested (demo: a single lineage with  at least 16 examples)
kf = randsample(find(sum(diCCL,2)>=16&sum(diCCL,2)<size(dmAUC22,2)/4),1);
kc = diCCL(kf,:);

% restrict compound data to appropriate subset of cell lines
dmAUC22 = dmAUC22(:,kc);

% create indicator matrix of cell mutation features by cell lines
diMut = false(numel(daMut.mutation_call),size(dmAUC22,2));
for z=1:numel(daMut.mutation_call)
    diMut(z,cell2mat(textscan(cell2mat(strrep(daMut.index_ccl(z),';',' ')),'%u'))) = true;
end

% restrict mutation data to appropriate subset of cell lines
diMut = diMut(:,kc);

% restrict analysis to mutation features with an appropriate number of examples
km = sum(diMut,2)>2&mean(diMut,2)<0.5;
diMut = diMut(km,:);
dfMut = DFkeeprow(daMut,km);

% define set of compounds to be tested (demo: a dozen random compounds)
tCpd = randsample(size(dmAUC22,1),12);
nCpd = numel(tCpd);

% setup dataframe to output table of enrichment results
outEnr = struct('context',[],'index_cpd',[],'cell_line_feature',[],'feat_row',[], ...
                'auc_thresh',[],'enr_p_val',[],'enr_conf',[],'enr_pur',[], ...
                'num_sens',[],'num_w_feat',[],'overlap',[]);

for z=1:nCpd % for each compound to be tested

    % verify enough cell lines were tested with compound in cell line context
    if (nnz(~isnan(dmAUC22(tCpd(z),:)))<3)
        continue;
    end

    % calculate raw enrichment output
    [ze.feat_row,ze.auc_thresh,ze.enr_p_val,ze.num_w_feat,ze.enr_conf,ze.num_sens,ze.enr_pur,ze.overlap] = sensenfex(dmAUC22(tCpd(z),:),diMut);

    % record context, compound ID, and mutation feature labels 
    ze.context = repmat(daCCL.cell_line_feature(kf),numel(ze.feat_row),1);
    ze.index_cpd = repmat(tCpd(z),numel(ze.feat_row),1);
    ze.cell_line_feature = dfMut.cell_line_feature(ze.feat_row);
    
    % append results to growing output dataframe
    outEnr = DFcat(outEnr,ze);
    
end

% define enrichment statistical and quality-control filters
f0 = (outEnr.enr_p_val==min(outEnr.enr_p_val));
f1 = (outEnr.auc_thresh < 13);
f2 = (outEnr.enr_p_val < 0.05);
f3 = (outEnr.enr_conf > 0.25);
f4 = (outEnr.enr_pur > 0.5);
f5 = (outEnr.overlap > 1);
fk = (f0|(f1&f2&f3&f4&f5));

% apply enrichment statistical and quality-control filters
outEnr = DFkeeprow(outEnr,fk);

% write output files for downstream analysis
DFwrite(outEnr,'output.P2.enrichment.txt',[wf filesep 'out']);

% clean up workspace
clear ans f* k* *Cpd p* s* z*;
