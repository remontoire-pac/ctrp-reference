function d = nanpwcor(u,V)
% d = nanpwcor(u,V)
% 
% Compute pairwise correlation ignoring NaNs between u and each row of V.
% Custom distance function for pdist (see pdist documentation):
%  input 1xP vector u, corrsponding to a single row of X
%  input MxP matrix V, corresponding to multiple rows of X
%    distfun must accept a matrix V with an arbitrary number of rows
%    distfun must return an Mx1 vector of distances d
%  kth element of d is the distance between u and V(k,:)
% Created 2013/12/19 PAC
% Last modified 2013/12/19 PAC
%

    % check for appropriate inputs
    if (numel(size(u))~=2||size(u,1)~=1)
        error('Input u must be a row vector.');
    end
    if (numel(size(V))~=2||size(u,2)~=size(V,2))
        error('Input V must be a matrix with the same number of columns as u.');
    end

    % setup d and dimensions for loops
    M = size(V,1);
    d = nan(M,1);
    kp = (repmat(~isnan(u),M,1))&(~isnan(V));

    for i=1:M
        d(i) = pdist2(u(kp(i,:)),V(i,kp(i,:)),'correlation');
    end

end
