function nz = nanzscore(X,flag)
% nz = nanzscore(X,flag)
% create zscore accounting for NaN (using, e.g., nanmean.m and nanstd.m
% optionally use robust z using MAD (1) or IQR (2)
% AMM/BSL/PAC 2014-04-04
% last modified AMM/BSL/PAC 2014-04-04
% last modified PAC (robust flag can be merely binary)

    nC = size(X,1);
    if (nargin<2) 
        flag = 0;
    end
    assert(isscalar(flag)&&isindex(flag+1)&&(flag<3),'Input flag must be 0, 1, or 2.');

    if (flag==2)
        mX = nanmedian(X,1);
        sX = 0.7413*iqr(X);
    elseif (flag==1)
        mX = nanmedian(X,1);
        sX = 1.4826*mad(X,1,1);
    else
        mX = nanmean(X,1);
        sX = nanstd(X,[],1);
    end

    nz = (X-repmat(mX,nC,1))./repmat(sX,nC,1);

end
