function flagTest = iseven(inMat)
%flagTest = iseven(inMat)
%Test matrix for containing only even positive integers (indices)
%Last modified 2011/08/05 PAC
%
%----------------------------------------------------------------
%workflow
%----------------------------------------------------------------
%Input any matrix.
%Check for integer data type or de facto integers.
%Ensure all integers are positive.
%Ensure all integers are even.
%Report test results as scalar logical.
%
%----------------------------------------------------------------
%parameters
%----------------------------------------------------------------
%"inMat" - any matrix
%
%----------------------------------------------------------------
%output
%----------------------------------------------------------------
%"flagTest" - logical reporting whether matrix passes test
%
%----------------------------------------------------------------

    %divide by 2 and run isindex
    newMat = inMat./2;
    if (isindex(newMat))
        flagTest = true;
    else
        flagTest = false;
    end
    
end
