function [row,thr,pv,nf,cnf,ns,pur,ov] = sensenfex(resp,feat,frac,filt,flag)
% [row,thr,pv,nf,cnf,ns,pur,ov] = sensenfex(resp,feat,frac,filt,flag)
%
% MODIFIED FROM sensenfast.m PAC 2016/02/11
%   - results are based on the p-value comparison only, no inclusion of 
%   -   purity or confidence in making the cutoff call (both are still reported)
%   - modified 2018/03/02 to use built-in fishertest.m rather than fisher22.m
%
% take 1xN vector (resp) of N responses (possibly including NaNs) as a continuous variable
%  and MxN matrix (feat) of N object assignments to M binary variables (no NaNs allowed)
%  optionally, take a fraction value (frac) of the number of resp values as a limiting case to try
%  optionally, take a filter value (filt) in the range of resp as a limiting case to try
%  optionally, specify with a flag (default=true) whether resp is sorted ascending (true) or descending (false)
%       and therefore whether filt is a maximum (true) or minimum (false) threshold
%
%  return column vectors of feature input rows, thresholds, log-odds, p-values,
%       numbers of features, confidence values, numbers responsive, purity values, numbers overlapping
%
%  follows sensenfast.m originally created 2015-04-15 PAC
%       - uses cumsum and repmat to build ctab tables for fisher exact test
%       - only computes fisher tests on unique set of 2x2 confusion matrices
%       - tries all possible thresholds in resp meeting the constraint of filt and flag
%       - much faster for processing multiple features per response than vice versa
%  

    assert(size(resp,1)==1,'Input resp must be a row vector.');
    assert(size(resp,2)>2,'Input resp must hold at least 3 values.');
    assert(nnz(~isnan(resp))>2,'Input resp must hold at least 3 non-NaN values.');
    assert(size(feat,2)==size(resp,2),'Input feat must have the same number of columns as resp.');
    assert(size(feat,1)>0,'Input feat must contain at least one row.');
    assert(isbinary(feat),'Input feat must be a binary matrix.');
    assert(nnz(isnan(feat))==0,'Input feat must not contain any NaNs.');
    feat = logical(feat);
    
    if (nargin<5||isequal(flag,[]))
        flag = true;
    end
    assert(isbinary(flag)&&isscalar(flag),'Input flag must be a binary scalar.');
    flag = logical(flag);
    if (nargin<4||isequal(filt,[]))
        filt = nanmedian(resp);
    end
    assert(isnumeric(filt)&&isscalar(filt),'Input filt must be a scalar number.');
    if (nargin<3||isequal(frac,[]))
        frac = 0.5;
    end
    assert(isnumeric(frac)&&isscalar(frac),'Input filt must be a scalar number.');
    assert(frac>0&&frac<=0.5,'Input frac must be a scalar fraction in (0,0.5].');
    
    resk = ~isnan(resp);
    respF = resp(resk);
    featF = feat(:,resk);
    
    if (flag)
        [respS,xs] = sort(respF,'ascend');
    else
        [respS,xs] = sort(respF,'descend');
    end
    featS = featF(:,xs);
    
    f22yy = full(cumsum(featS,2));
    f22ny = repmat(full(sum(featS,2)),1,size(f22yy,2))-f22yy;
    f22yn = repmat(1:numel(xs),size(f22yy,1),1)-f22yy;
    f22nn = ones(size(f22yy))*size(f22yy,2)-f22yn-f22ny-f22yy;

    if (flag)
        resc = 1:min(find(respS<filt,1,'last'),floor(frac*numel(respS)));
    else
        resc = 1:min(find(respS>filt,1,'last'),floor(frac*numel(respS)));
    end
    
    if (numel(resc)==0)
        row = NaN;
        thr = NaN;
        pv = NaN;
        nf = NaN;
        cnf = NaN;
        ns = NaN;
        pur = NaN;
        ov = NaN;
        return;
    else
        f22yy = f22yy(:,resc);
        f22ny = f22ny(:,resc);
        f22yn = f22yn(:,resc);
        f22nn = f22nn(:,resc);
        featT = featS(:,resc);

        N = [f22nn(:) f22yn(:) f22ny(:) f22yy(:)];
        [Nb,Nm,Nn] = unique(N,'rows','first');
        f22pv = nan(length(Nm),1);

        for xi=1:length(Nm)
            ctab = [Nb(xi,1) Nb(xi,3); ...
                    Nb(xi,2) Nb(xi,4)];
            [~,f22pv(xi)] = fishertest(ctab,'Tail','right');
        end
        
        f22nf = full(Nb(:,3)+Nb(:,4));
        f22cnf = full(Nb(:,4)./(Nb(:,3)+Nb(:,4)));
        f22cnf(isnan(f22cnf)) = 0;
        f22ns = full(Nb(:,2)+Nb(:,4));
        f22pur = full(Nb(:,4)./(Nb(:,2)+Nb(:,4)));
        f22ov = full(Nb(:,4));

          vec_pv = nan(size(featT));
          vec_nf = nan(size(featT));
         vec_cnf = nan(size(featT));
          vec_ns = nan(size(featT));
         vec_pur = nan(size(featT));
          vec_ov = nan(size(featT));
   
         vec_pv(:) = f22pv(Nn);
         vec_nf(:) = f22nf(Nn);
        vec_cnf(:) = f22cnf(Nn);
         vec_ns(:) = f22ns(Nn);
        vec_pur(:) = f22pur(Nn);
         vec_ov(:) = f22ov(Nn);

        index = find((tiedrank(vec_pv')'==repmat(min(tiedrank(vec_pv')',[],2),1,size(vec_pv,2))));
        [row,col] = ind2sub(size(vec_pv),index);
        thr = median([respS(col)' respS(col+1)'],2);
        pv = vec_pv(index);
        nf = vec_nf(index);
        cnf = vec_cnf(index);
        ns = vec_ns(index);
        pur = vec_pur(index);
        ov = vec_ov(index);
    end

end
