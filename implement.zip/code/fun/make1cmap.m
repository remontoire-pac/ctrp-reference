function c1 = make1cmap(color,dir,d,p,con)
% c1 = make1cmap(color,dir,d,p,con)
%
% Make hi-res red-white colormap
% Last modified 2014/04/16 PAC
%
    if (nargin<5||isequal(con,[]))
        con = true; % default more color (nonlinear only); false for bleaching
    end
    if (nargin<4||isequal(p,[]))
        p = 1; % default linear, use larger integers for nonlinearity
    end
    if (nargin<3||isequal(d,[]))
        d = 64; % default depth 64
    end
    if (nargin<2||isequal(dir,[]))
        dir = true; % default color high, white low; false to invert
    end
    if (nargin<1||isequal(color,[]))
        color = 1;
    end
    
    assert(islogical(con),'Compressor con must be true or false.');
    assert(isindex(p),'Nonlinear exponent p must be a positive integer.');
    assert(iseven(d)&isindex(d),'Color depth d must be an even positive integer.');
    assert(islogical(dir),'Direction dir must be true or false.');
    assert(isindex(color)&&color<4,'Input color =1 (red), =2 (green), =3 (blue).');

    c1 = nan(d,3);
    c1(1:d,color)   = ones(d,1);   % color 1=r, 2=g, 3=b
    for cc=1:3
        if (cc==color)
            continue;
        else
            c1(1:d,cc)   = ((1-1/d):-(1/d):0); % other two fade white to black
        end
    end
   
    if (con==false)
        p = 1/p;
    end
    
    c1 = c1.^p;
    
    if (dir==false)
        c1 = c1(end:-1:1,:);
    end
    
end
