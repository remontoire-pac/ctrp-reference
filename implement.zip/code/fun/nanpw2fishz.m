function [MN,pwCC,pwCT,nd] = nanpw2fishz(A,B)
% [MN,pwCC,pwCT,nd] = nanpw2fishz(A,B)
% 
% Use pdist2 to compute cross-pairwise correlations ignoring NaNs
% Input is 2 matrices A (which is MxP) and B (which is NxP).
% Matrices A and B can have NaNs but must each have P total columns.
% Normalize for the appropriate number of non-NaN elements shared by each pair.
% Create output (MN) similar to the standard output of pdist2, i.e., (MxN).
% Also optionally returns raw correlation coefficient (pwCC), number of shared
% non-NaNs (pwCT), and the scalar number of non-NaN scores (nd).
% Requires nanpwcor.m
% 
% Created 2014/09/06 PAC
% Last modified 2014/09/06 PAC
%

    P = size(A,2);
    assert(isequal(P,size(B,2)),'Matrices A and B must each have P columns.');
    assert(P>3,'Matrices A and B must have at least 4 columns.');

    pwCT = double(~isnan(A))*double(~isnan(B')); % count shared non-NaNs
    pwCD = pdist2(A,B,@nanpwcor); % run special pdist function that removes NaNs
    pwCC = 1-pwCD; % convert correlation distance to correlation coefficient
    MN = 0.5.*log((1+pwCC)./(1-pwCC)).*sqrt(pwCT-3); % perform Fisher's Z transformation
    MN(pwCT<4) = NaN; % set correlations back to NaN if fewer than 4 shared non-NaNs
    nd = nnz(~isnan(MN));

end
