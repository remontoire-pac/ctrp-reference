% clean workspace
clear; tic;

% map a directory structure 
wf = 'i:\MATLAB\mimb'; % customize to local environment
addpath(genpath([wf '\code'])); % need \code, \code\fun, \code\fun\df, \code\fun\df\util
cd([wf '\data']); % work in data folder

% PROCEDURE 1: fit and integrate concentration-response score curves

    % read data and run detailed curve-fitting script
    dtScore = DFread('v20.data.per_cpd_pre_qc.txt',[],16384);
    mtExpt = DFread('v20.meta.per_experiment.txt',[wf '\meta']);
    
    run procedure1CurveFit.m;
    
    % read relevant metadata for interpretation
    mtCpd20 = DFread('v20.meta.per_compound.txt',[wf '\meta']);
    mtCCL = DFread('v20.meta.per_cell_line.txt',[wf '\meta']);
    
    % select two suitable curves to illustrate and extract curve data
    tCRC = outFit.curve_id( ...
        [find(outFit.area_under_curve<prctile(outFit.area_under_curve,5),1,'first'); ...
        find(outFit.area_under_curve>prctile(outFit.area_under_curve,50),1,'first')] ...
        );
    tx1 = log2(outPts.cpd_conc_umol(outPts.curve_id==tCRC(1)));
    ty1 = outPts.cpd_avg_pv(outPts.curve_id==tCRC(1));
    tfx1 = outPts.cpd_pred_pv(outPts.curve_id==tCRC(1));
    tfe1 = outPts.cpd_pv_errorbar(outPts.curve_id==tCRC(1));
    tx2 = log2(outPts.cpd_conc_umol(outPts.curve_id==tCRC(2)));
    ty2 = outPts.cpd_avg_pv(outPts.curve_id==tCRC(2));
    tfx2 = outPts.cpd_pred_pv(outPts.curve_id==tCRC(2));
    tfe2 = outPts.cpd_pv_errorbar(outPts.curve_id==tCRC(2));
    
    % plot original points and predicted curves with error bars
    figure();
    hold on;
    scatter(tx1,ty1,60,'r','marker','x');
    errorbar(tx1,tfx1,tfe1,'color','r');
    scatter(tx2,ty2,60,'b','marker','x');
    errorbar(tx2,tfx2,tfe2,'color','b');
    ylim([-0.25 1.5]);
    ylabel('percent viability');
    xlabel('log_2(micromolar)');
    hold off;
    legend({[cell2mat(mtCCL.ccl_name(mtCCL.master_ccl_id==outFit.master_ccl_id(outFit.curve_id==tCRC(1)))) ' cells'], ...
            ['(AUC = ' num2str(sprintf('%4.1f',outFit.area_under_curve(outFit.curve_id==tCRC(1)))) ')'], ...
            [cell2mat(mtCCL.ccl_name(mtCCL.master_ccl_id==unique(outFit.master_ccl_id(outFit.curve_id==tCRC(2))))) ' cells'], ...
            ['(AUC = ' num2str(sprintf('%4.1f',outFit.area_under_curve(outFit.curve_id==tCRC(2)))) ')']}, ...
            'Location','southwest');
    title([cell2mat(mtCpd20.cpd_name(mtCpd20.master_cpd_id==unique(outFit.master_cpd_id))) ' sensitivity']);
    clear t*;
    
% PROCEDURE 2: compute enrichment of mutation features among sensitive cell lines

    % read data and run detailed enrichment analysis script
    dtAUC22 = DFread('v22.data.auc_sensitivities.txt');
    daCCL = DFread('v22.anno.ccl_anno_features.txt');
    daMut = DFread('v22.anno.ccl_mut_features.txt');

    run procedure2Enrichment.m;

    % read relevant metadata for interpretation
    mtCpd22 = DFread('v22.meta.per_compound.txt',[wf '\meta']);

    % select a suitable enrichment result to illustrate and extract data
    tEnr = find(outEnr.enr_p_val==min(outEnr.enr_p_val),1,'first');
    tx3 = dmAUC22(outEnr.index_cpd(tEnr),:);
    ty3 = diMut(outEnr.feat_row(tEnr),:);
    ty3 = ty3(~isnan(tx3));
    tx3 = tx3(~isnan(tx3));
    [tx3,ts] = sort(tx3,'ascend');
    ty3 = ty3(ts);
    tz3 = nanzscore(tx3')';
    tth = outEnr.auc_thresh(tEnr);
    tfp = outEnr.enr_p_val(tEnr);
    tnf = outEnr.num_w_feat(tEnr);
    tns = outEnr.num_sens(tEnr);
    tov = outEnr.overlap(tEnr);
    tnt = numel(tx3);
    
    % perform one-sided t-test as secondary statistic
    [~,ttp] = ttest2(tx3(~ty3),tx3(ty3),[],'right','unequal');
    
    % create labels for visualization from appropriate metadata
    tcpn = cell2mat(mtCpd22.cpd_name(outEnr.index_cpd(tEnr)));
    tctx = cell2mat(outEnr.context(tEnr));
    tclf = cell2mat(outEnr.cell_line_feature(tEnr));
    
    % plot enrichment analysis as heatmap and boxplot representations
    figure();
    colormap(make1cmap(1,false,256,1,false));
    subplot(2,3,[1 2]);
    imagesc(tz3,[min(tz3) 0]);
    title([cellstr([tcpn ' AUC (z-score < 0)']); ...
           cellstr(['in ' strrep(tctx,'_',' ') ...
           ' (' num2str(tns) ' with AUC < ' ...
           num2str(sprintf('%4.1f',tth)) ')'])]);
    set(gca,'XTickLabels',[],'YTickLabels',[]);
    subplot(2,3,[4 5]);
    imagesc(sqrt(0.5*(~ty3)+0.5*[zeros(1,tns) ones(1,tnt-tns)]));
    title([cellstr(['Mut: ' strrep(tclf,'_',' ')]); ...
           cellstr(['(' num2str(tov) ' overlap from ' num2str(tnf) ...
           ' of ' num2str(tnt) ' total; Fisher p-value = ' ...
           num2str(sprintf('%4.2e',tfp)) ')'])]);
    set(gca,'XTickLabels',[],'YTickLabels',[]);
    subplot(2,3,[3 6]);
    boxplot(tx3,ty3);
    set(gca,'XTickLabels',{'lacks Mut';'has Mut'});
    title([cellstr([tcpn ' AUC (original scale)']); ...
           cellstr(['T-test p-value = ' num2str(sprintf('%4.2e',ttp))])]);
    clear t*;

% PROCEDURE 3: compute correlation of expression features with compound sensitivity

    % read data and run detailed correlation analysis script
    dtAUC21 = DFread('v21.data.auc_sensitivities.txt');
    dtGEX = DFread('v21.data.gex_avg_log2.txt');
    
    run procedure3Correlation.m;

    % read relevant metadata for interpretation
    mtGEX = DFread('v21.meta.gex_features.txt',[wf '\meta']);

    % select a suitable correlation result to illustrate and extract data
    tCor = find(abs(outCor.cor_coef)==max(abs(outCor.cor_coef)),1,'first');
    tx4 = dmAUC21(outCor.index_cpd(tCor),:);
    ty4 = dmGEX(outCor.cor_col_id(tCor),:);
    tfp = outCor.cor_p_val(tCor);
    tcz = outCor.cor_z_score(tCor);
    tcc = outCor.cor_coef(tCor);
    tnc = outCor.num_of_ccl(tCor);
     
    % create labels for visualization from appropriate metadata
    tcpn = cell2mat(mtCpd20.cpd_name(mtCpd20.master_cpd_id==outCor.master_cpd_id(tCor)));
    tctx = cell2mat(outCor.context(tCor));
    tgen = cell2mat(mtGEX.gene_primary_name(mtGEX.idx_gene_feature==outCor.idx_gene_feature(tCor)));
    
    % plot correlation scatterplot and regression line
    figure();
    scatter(tx4,ty4,64,'r','o','filled');
    tline = lsline;
    set(tline,'LineWidth',2,'Color','k');
    xlabel([tcpn ' AUC']);
    ylabel([tgen ' GEX']);
	ylim([min(dmGEX(:)) max(dmGEX(:))]);
    hold off;
    title([strrep(tctx,'_',' ') ...
           ' (' num2str(tnc) ' lines): correlation: ' num2str(sprintf('%4.2f',tcc)) ... 
           ' (z = '  num2str(sprintf('%4.2f',tcz)) '; p = ' num2str(sprintf('%4.2e',tfp)) ')']);
    clear t*;

toc;
